const express = require('express')
const salary = express.Router()
var moment = require("moment");
const morgan = require('morgan')
const multer = require('multer');
const bodyParser = require('body-parser')
const db = require('../db')
const verifyJWT = require('../Middleware/auth')
const xlsx = require('xlsx');
const sql = require('mssql');
const cors = require('cors');
const { validate } = require('node-cron');
salary.use(cors())
salary.use(morgan('dev'));

const corsOptions = {
    origin: true,
    credentials: true
}

salary.options('*', cors(corsOptions));
salary.use(bodyParser.urlencoded({ extended: false }));
salary.use(bodyParser.json());

const storage = multer.memoryStorage();
const upload_1 = multer({ storage });

/////------------
async function checkPayscale(PayscaleId,EffectiveDate){
  try {
console.log(PayscaleId,EffectiveDate);

if(!PayscaleId && !EffectiveDate){
  return {status:false ,message:'Payscale Header Not selected'}
}
else{
    const pool = await db.poolPromise;
    const CheckPayscale = pool.request();
    CheckPayscale.input('payscaleId',sql.Int,PayscaleId)
    CheckPayscale.input('Effective_Date',sql.Date,EffectiveDate)
    const result = await CheckPayscale.execute('CheckPayscale')

    console.log('result' ,result);
    if(result.recordset.length>0){
        if(result.recordset[0].IsLatest ==='Not Latest' && result.recordset[1].IsLatest ==='Not Latest' && result.recordset[2].IsLatest ==='Not Latest' && result.recordset[0].LatestDate !=null && result.recordset[1].LatestDate !=null && result.recordset[2].LatestDate !=null  ){
          return {status:false , type:'Already', message:`Payscale Master Already Available With this Month`}
        }
        else if( result.recordset[0].IsLatest ==='Not Latest' && result.recordset[1].IsLatest ==='Not Latest' && result.recordset[2].IsLatest ==='Not Latest'  && result.recordset[0].LatestDate ==null && result.recordset[1].LatestDate ==null && result.recordset[2].LatestDate ==null  ){
          return {status:true , type :'New',message:`New Payscale New to be created  with Latest Effective Date ${DateFormat_ddmmyyyy(result.recordset[1].LatestDate)}`}
        }
        else if(result.recordset[0].IsLatest ==='Latest' && result.recordset[1].IsLatest ==='Latest' && result.recordset[2].IsLatest ==='Latest'){
          return {status:true ,
                  message:`Payscale Can Be Created and Latest Effective Date ${DateFormat_ddmmyyyy(result.recordset[1].LatestDate)}` ,
                  type:'Exist',
                  earningEffective : result.recordset[0].LatestDate ,
                  deductionEffective : result.recordset[1].LatestDate ,
                  ptcEffective : result.recordset[2].LatestDate 
                
                }
        }
    } 
}
 } catch (error) {
    console.error('Error executing Chcek payscale Function:', error);
  }
}

async function chcekDuplicatPayscale(Effective_Date,PayScale_ID,Plant_Code){
try {
  const pool = await db.poolPromise;
  const CheckDupPayscale = pool.request();
  CheckDupPayscale.input('PayScale_ID',sql.Int,PayScale_ID)
  CheckDupPayscale.input('Effective_Date',sql.Date,Effective_Date)
  CheckDupPayscale.input('Plant',sql.VarChar(5),Plant_Code)
  const result = await CheckDupPayscale.execute('ChcekDupLicatePayscale')

  console.log('result' ,result);

  if(result && result.recordset.length >0){
    return   {status:false , type:'Already', message:`Payscale Master Already Availabel in this Month ${DateFormat_ddmmyyyy(Effective_Date)}`}
    
  }else{
    return   {status:true , type:'Already', message:`Payscale Master Can Be for Month ${DateFormat_ddmmyyyy(Effective_Date)}`}
 
  }

} catch (error) {
  console.error('Error executing Chcek duplicate payscale Function:', error);
}
}

function convertToDecimal(value) {
  
  if (value == "null" || value== null || value == '' ) {
    return 0; 
  }
  else if (isNaN(value)) {
    return 0;   }
   else{
    return parseFloat(value); 
   } 
  
}


function DateFormat_ddmmyyyy(date){
  const dateObj = new Date(date);
  const day = String(dateObj.getDate()).padStart(2, '0'); 
const month = String(dateObj.getMonth() + 1).padStart(2, '0'); 
const year = dateObj.getFullYear();
return `${day}-${month}-${year}`
}


async function firstTimeSalary(type,PayscaleDetails ,EarningDetails,DeductionDetails,PaidToContractorDetails,CreatedBy){
  try {

    console.log(DeductionDetails);
    
    const pool = await db.poolPromise;
      const InsertPayscale = pool.request();
      InsertPayscale.input('PayScale_ID',sql.Int,PayscaleDetails.Payscale_ID)
      InsertPayscale.input('Effective_Date',sql.Date,PayscaleDetails.EffectiveDate)

      InsertPayscale.input('Stipend', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Stipend) )
      InsertPayscale.input('Basic', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Basic_amt) )
      InsertPayscale.input('DA', sql.Decimal(18, 2),convertToDecimal(EarningDetails.DA_amt) )
      InsertPayscale.input('HRA', sql.Decimal(18, 2),convertToDecimal(EarningDetails.HRA_amt) )
      InsertPayscale.input('Leave_Salary', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Leave_Salary_amt) )
      InsertPayscale.input('Washing_allow', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Washing_allow_amt) )
      InsertPayscale.input('Monthly_Bonus', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Monthly_Bonus_amt) )
      InsertPayscale.input('Sat_and_Mon_Incentive', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Sat_Mon_amt) )
      InsertPayscale.input('Monthly_Attn_Incentive', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Attendance_Bonus_amt) )
      InsertPayscale.input('Retention_Incentive', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Retention__amt) )
      InsertPayscale.input('Spl_allow', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Spcl_allow_amt) )
      InsertPayscale.input('Night_shift_allowance', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Night_shift_allow_amt) )
      InsertPayscale.input('Skilled_allow_P3', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Skilled_allow_amt) )
      InsertPayscale.input('Amenities_Allow', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Amenities_allow_amt) )
      InsertPayscale.input('Other_allowance_1', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Other_allow_1_amt) )
      InsertPayscale.input('Other_allowance_2', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Other_allow_2_amt) )
      InsertPayscale.input('Other_allowance_3', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Other_allow_3_amt) )
      InsertPayscale.input('Other_allowance_4', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Other_allow_4_amt))
      InsertPayscale.input('Gross_Earnings', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Gross_Earnings) )
      //newly added karthi on 24-09-2025 ---salary element added
      InsertPayscale.input('hostel', sql.Decimal(18, 2),convertToDecimal(EarningDetails.hostel) )
      InsertPayscale.input('Food', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Food) )
      InsertPayscale.input('Workallowance', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Workallowance) )
      // end 
      InsertPayscale.input('Canteen', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Canteen_amt) )
      InsertPayscale.input('Transport', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Transport_amt) )
      InsertPayscale.input('Professional_Tax', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Professional_Tax_amt) )
      InsertPayscale.input('WC_Policy', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.WC_Policy_amt) )
      InsertPayscale.input('Insurance', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Insurance) )
      InsertPayscale.input('Shoe_FirstTime', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Shoes_amt) )
      InsertPayscale.input('Uniform_FirstTime', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Uniform_Tshirt) )
      InsertPayscale.input('Glass_FirstTime', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Goggles) )
      InsertPayscale.input('Coat_FirstTime', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Coat) )
      InsertPayscale.input('Other_deduction_1', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Other_deduction_1_amt) )
      InsertPayscale.input('Other_deduction_2', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Other_deduction_2_amt) )
      InsertPayscale.input('Other_deduction_3', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Other_deduction_3_amt) )
      InsertPayscale.input('Other_deduction_4', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Other_deduction_4_amt) )
      InsertPayscale.input('Tot_Deduction', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Gross_Deduction) )

      InsertPayscale.input('Service_Charge_Fixed',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Service_chrge)  )
      InsertPayscale.input('Service_charges_Percentage',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Service_percent)  )
      InsertPayscale.input('SC_Base',sql.VarChar(20),PaidToContractorDetails.Sc_Base )
      InsertPayscale.input('NSDC_Contribution',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.NSDC) )
      InsertPayscale.input('Uniform_Charges',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Uniform_Charges_amt) )
      InsertPayscale.input('Labour_Welfare_Fund',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.LWF) )
      InsertPayscale.input('Learning_Fees',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Learning_Fee) )
      InsertPayscale.input('Workmen_Compensation',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Workmen_Compensation) )
      InsertPayscale.input('Insurance_Premium',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Insurance_Premium) )
      InsertPayscale.input('Higher_Education_Fee',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Higher_Education_Fee) )
      InsertPayscale.input('Emp_Comp_Ins',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Emp_Comp_Ins) )
      InsertPayscale.input('Created_By',sql.VarChar(20), CreatedBy )
      // console.log(InsertPayscale);
      
     const response = await InsertPayscale.execute('NewPayscaleInsert')
      if(type == 'Exist'){
        return {Status : true , message: `Payscale Changed From effective Date ${PayscaleDetails.EffectiveDate}`}
      }
      else if(type == 'New'){
        return {Status : true , message: `New Payscale Added with a effective Date ${PayscaleDetails.EffectiveDate}`}
      }
  } catch (error) {
    console.error('Error executing firstTimeSalary Function:', error);
    return {Status : false , message: `Error In Program , Payscale Not Created`}

  }
}




salary.post('/addpayscale',async(req,res) =>{
  console.log(req.body);
  try {
    const {PayscaleDetails ,EarningDetails,DeductionDetails,PaidToContractorDetails,Plant,CreatedBy} = req.body
    // Chcek Payscale Validationn
    const validatDups = await chcekDuplicatPayscale(PayscaleDetails.EffectiveDate, PayscaleDetails.Payscale_ID ,Plant)
console.log(validatDups);

if(validatDups.status ==false ){
  return res.status(400).json(validatDups.message)
}else{

    const validatePayscale = await checkPayscale(PayscaleDetails.Payscale_ID, PayscaleDetails.EffectiveDate)
    console.log(validatePayscale);
    // Already
    if(validatePayscale.status === false && validatePayscale.type === 'Already' ){
      return res.status(400).json(validatePayscale.message)
    }
    // Exist
    else if(validatePayscale.status === true && validatePayscale.type === 'Exist' ){
      
      const {earningEffective ,deductionEffective,ptcEffective } =validatePayscale
      const pool = await db.poolPromise;
      const InactivePayscale = pool.request();
      InactivePayscale.input('payscaleId',PayscaleDetails.Payscale_ID)
      InactivePayscale.input('Earning_Effective_Date', earningEffective)
      InactivePayscale.input('Deduction_Effective_Date',deductionEffective)
      InactivePayscale.input('PTC_Effective_Date',ptcEffective)
      InactivePayscale.input('CreatedBy',CreatedBy)
      const data = await InactivePayscale.execute('InactiveOld_Payscale')

      const ExistPaycale =  await firstTimeSalary('Exist', PayscaleDetails ,EarningDetails,DeductionDetails,PaidToContractorDetails,CreatedBy)
      if(ExistPaycale.Status === true) {
        return res.status(200).json(ExistPaycale.message)
      }else{
        return res.status(400).json(ExistPaycale.message)
      }
    }
    // NEW
    else if(validatePayscale.status === true && validatePayscale.type === 'New' ){

      const NewPaycale =  await firstTimeSalary('New',PayscaleDetails ,EarningDetails,DeductionDetails,PaidToContractorDetails,CreatedBy)
     console.log(NewPaycale);
     
      if(NewPaycale.Status === true) {
        return res.status(200).json(NewPaycale.message)
      }else{
        return res.status(400).json(NewPaycale.message)
      }

    }

  }

  } catch (error) {
    console.log(error);
    return res.status(500).json('Error In Connection')
  }
})


salary.post('/updatepayscale',async(req,res) =>{
  // console.log(req.body);
  try {
    const {PayscaleDetails ,EarningDetails,DeductionDetails,PaidToContractorDetails,Plant,CreatedBy} = req.body
console.log(PayscaleDetails ,EarningDetails,DeductionDetails,PaidToContractorDetails,Plant,CreatedBy);
  
const pool = await db.poolPromise;
const UpdatePayscale = pool.request();
UpdatePayscale.input('PayScale_ID',sql.Int,PayscaleDetails.Payscale_ID)
UpdatePayscale.input('Modified_By',sql.VarChar(20), CreatedBy )

// UpdatePayscale.input('Effective_Date',sql.Date,PayscaleDetails.EffectiveDate)

UpdatePayscale.input('Stipend', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Stipend) )
UpdatePayscale.input('Basic', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Basic_amt) )
UpdatePayscale.input('DA', sql.Decimal(18, 2),convertToDecimal(EarningDetails.DA_amt) )
UpdatePayscale.input('HRA', sql.Decimal(18, 2),convertToDecimal(EarningDetails.HRA_amt) )
UpdatePayscale.input('Leave_Salary', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Leave_Salary_amt) )
UpdatePayscale.input('Washing_allow', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Washing_allow_amt) )
UpdatePayscale.input('Monthly_Bonus', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Monthly_Bonus_amt) )
UpdatePayscale.input('Sat_and_Mon_Incentive', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Sat_Mon_amt) )
UpdatePayscale.input('Monthly_Attn_Incentive', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Attendance_Bonus_amt) )
UpdatePayscale.input('Retention_Incentive', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Retention__amt) )
UpdatePayscale.input('Spl_allow', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Spcl_allow_amt) )
UpdatePayscale.input('Night_shift_allowance', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Night_shift_allow_amt) )
UpdatePayscale.input('Skilled_allow_P3', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Skilled_allow_amt) )
UpdatePayscale.input('Amenities_Allow', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Amenities_allow_amt) )
UpdatePayscale.input('Other_allowance_1', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Other_allow_1_amt) )
UpdatePayscale.input('Other_allowance_2', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Other_allow_2_amt) )
UpdatePayscale.input('Other_allowance_3', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Other_allow_3_amt) )
UpdatePayscale.input('Other_allowance_4', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Other_allow_4_amt) )


  UpdatePayscale.input('hostel', sql.Decimal(18, 2),convertToDecimal(EarningDetails.hostel) )
      UpdatePayscale.input('Food', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Food) )
      UpdatePayscale.input('Workallowance', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Workallowance) )
// UpdatePayscale.input('Gross_Earnings', sql.Decimal(18, 2),convertToDecimal(EarningDetails.Gross_Earnings) )

UpdatePayscale.input('Canteen', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Canteen_amt) )
UpdatePayscale.input('Transport', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Transport_amt) )
UpdatePayscale.input('Professional_Tax', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Professional_Tax_amt) )
UpdatePayscale.input('WC_Policy', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.WC_Policy_amt) )
UpdatePayscale.input('Insurance', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Insurance) )
UpdatePayscale.input('Shoe_FirstTime', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Shoes_amt) )
UpdatePayscale.input('Uniform_FirstTime', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Uniform_Tshirt) )
UpdatePayscale.input('Glass_FirstTime', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Goggles) )
UpdatePayscale.input('Coat_FirstTime', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Coat) )
UpdatePayscale.input('Other_deduction_1', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Other_deduction_1_amt) )
UpdatePayscale.input('Other_deduction_2', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Other_deduction_2_amt) )
UpdatePayscale.input('Other_deduction_3', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Other_deduction_3_amt) )
UpdatePayscale.input('Other_deduction_4', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Other_deduction_4_amt) )
// UpdatePayscale.input('Tot_Deduction', sql.Decimal(18, 2),convertToDecimal(DeductionDetails.Gross_Deduction) )

  if(PaidToContractorDetails.Service_Type == 'Percent'){
    UpdatePayscale.input('Service_Charge_Fixed',sql.Decimal(18, 2), 0)
    UpdatePayscale.input('Service_charges_Percentage',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Service_percent)  )
  }else if(PaidToContractorDetails.Service_Type == 'Value'){
    UpdatePayscale.input('Service_Charge_Fixed',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Service_chrge)  )
UpdatePayscale.input('Service_charges_Percentage',sql.Decimal(18, 2), 0  )
  }

UpdatePayscale.input('SC_Base',sql.VarChar(20),PaidToContractorDetails.Sc_Base )
UpdatePayscale.input('NSDC_Contribution',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.NSDC) )
UpdatePayscale.input('Uniform_Charges',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Uniform_Charges_amt) )
UpdatePayscale.input('Labour_Welfare_Fund',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.LWF) )
UpdatePayscale.input('Learning_Fees',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Learning_Fee) )
UpdatePayscale.input('Workmen_Compensation',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Workmen_Compensation) )
UpdatePayscale.input('Insurance_Premium',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Insurance_Premium) )
UpdatePayscale.input('Higher_Education_Fee',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Higher_Education_Fee) )
UpdatePayscale.input('Emp_Comp_Ins',sql.Decimal(18, 2),convertToDecimal(PaidToContractorDetails.Emp_Comp_Ins) )
// console.log(UpdatePayscale);

const response = await UpdatePayscale.execute('PayscaleUpdate')
console.log(response);
if(response.recordset[0].Status == 'true'){
  res.status(200).json('Updated Successfully')
}else{
  res.status(400).json('Payscale not updated')
}

  } catch (error) {
    console.log(error);
    return res.status(500).json('Error In Connection')
  }
})






salary.get('/getPayscaleHeader',async(req,res)=>{
  try {
    const pool = await db.poolPromise;
    const request = pool.request();
    const Plant_Code =  req.query.plant
    request.input('Plant_Code', Plant_Code)
    const result = await request.execute('GetPayscaleHeader').then(function(recordset){
      res.status(200).json(recordset.recordset)
      // console.log(recordset.recordset)
  })
  } catch (error) {
    console.error('Error executing stored procedure:', err);
    res.status(400).send("Error while Getting data :");
  }
})
salary.get('_combine',async(req,res)=>{
  try {
    const pool = await db.poolPromise;
    const request = pool.request();
    const Plant_Code =  req.query.plant
    const userEmpcode =  req.query.userEmpcode
    request.input('plant_code', Plant_Code)
    request.input('userEmpcode', userEmpcode)
    const result = await request.execute('GetPayscaleHeader_combine').then(function(recordset){
      res.status(200).json(recordset.recordset)
      // console.log(recordset.recordset)
  })
  } catch (error) {
    console.error('Error executing stored procedure:', err);
    res.status(400).send("Error while Getting data :");
  }
})
salary.get('/getPayscaleHeader_combine', async (req, res) => {
  try {
    const pool = await db.poolPromise;
    const request = pool.request();
    const Plant_Code = req.query.plant;
    const userEmpcode = req.query.userEmpcode;

    request.input('plant_code', Plant_Code);
    request.input('userEmpcode', userEmpcode);

    const result = await request.execute('getPayscleMaster_combine');
    res.status(200).json(result.recordset);

  } catch (error) { // ✅ Use "error" instead of "err"
    console.error('Error executing stored procedure:', error);
    res.status(400).send("Error while Getting data");
  }
});










salary.get('/get_tr',  async(req,res) => {
const apln_slno =  req.query.apln_slno
const apln_status =  req.query.apln_status
const gen_id =  req.query.gen_id
// console.log(plant_code)
    try{
        const pool = await db.poolPromise;
        const request = pool.request();
        request.input('apln_slno', apln_slno)
        request.input('apln_status', apln_status)
        request.input('gen_id', gen_id)
        const result = await request.execute('trainee_data').then(function(recordset){
            res.status(200).json(recordset.recordset)
           // console.log(recordset.recordset)
        })
}catch(err){
    console.error('Error executing stored procedure:', err);
    res.status(400).send("Error while Getting data :");
}


})
salary.get('/get_tr_dtls',  async(req,res) => {
const apln_slno =  req.query.apln_slno

//console.log(req.query);

    try{
        const pool = await db.poolPromise;
        const request = pool.request();
        request.input('apln_slno',sql.Int, apln_slno)
        const result = await request.execute('trainee_data_ForSal').then(function(recordset){
            res.status(200).json(recordset.recordset)
            // console.log(recordset.recordset)
        })
}catch(err){
    console.error('Error executing stored procedure:', err);
    res.status(400).send("Error while Getting data :");
}


})


salary.get('/conpay', async (req, res) => {
  const plant_code = req.query.plant_Code;
  const con_id = req.query.con_id;

  try {
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('plant_code',sql.Int, plant_code);
    request.input('con_id',sql.Int, con_id);

   // console.log(request);
    
    const result = await request.execute('Con_Payscale_data_1');
    // console.log(result);
    
    if (result && result.recordset) {
      res.status(200).json(result.recordset);
    } else {
      res.status(200).json([]); 
    }
  } catch (error) {
    console.error('Error executing stored procedure:', error);
    res.status(500).json("Error while Getting Payscale data");
  }
});
salary.post('/SinglePay', async (req, res) => {

  console.log(req.body);
  
  const  {plant_Code,
    con_id,
    PayScale_ID,
   
  } = req.body

  try {
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('plant_code',sql.Int, plant_Code);
    request.input('con_id',sql.Int, con_id);
    request.input('PayScale_ID',sql.Int, PayScale_ID);

   // console.log(request);
    
    const result = await request.execute('Con_Payscale_data_Single');
    console.log(result);
    
    if (result && result.recordset) {
      res.status(200).json(result.recordset);
    } else {
      res.status(200).json([]); 
    }
  } catch (error) {
    console.error('Error executing stored procedure:', error);
    res.status(500).json("Error while Getting Payscale data");
  }
});




salary.get('/payscale',async(req,res)=>{
  const plant_code = req.query.plant_code
try{
  const pool = await db.poolPromise;
  const request = pool.request();
  request.input('plant_code',req.query.plant_code )
  result  = await request.execute('Get_Payscale').then(function(recordset){
    res.status(200).json(recordset.recordset)

    
  } );
}catch(error){
  console.error('Error executing stored procedure:', error);
  res.status(400).send("Error while Getting data :");
}

})

salary.get('/payscale_combine',async(req,res)=>{
  const plant_code = req.query.plant_code
try{
  const pool = await db.poolPromise;
  const request = pool.request();
  request.input('plant_code',req.query.plant_code )
  request.input('userEmpcode',req.query.userEmpcode )
  result  = await request.execute('Get_Payscale_combine').then(function(recordset){
    res.status(200).json(recordset.recordset)

    
  } );
}catch(error){
  console.error('Error executing stored procedure:', error);
  res.status(400).send("Error while Getting data :");
}

})

salary.post('/add_Salry', async(req,res)=>{
  console.log(req.body);
  const{PayScale_ID,plant_Code,Effective_Date,apln_slno, Requested_By } = req.body
  try {
   
    const pool = await db.poolPromise;
    const request1 = pool.request();
    console.log("select * from Mst_Emp_PayScale where Apln_slno= '"+apln_slno+"'");
    
    const chcek = await request1.query("select * from Mst_Emp_PayScale where Apln_slno= '"+apln_slno+"'  ")
console.log(chcek);

console.log(chcek && chcek.recordset.length > 0);



    if(chcek && chcek.recordset.length > 0){
// Exist
      if(chcek.recordset[0].Approval_Status === 'REWORK'){
      const request2 = pool.request();
      request2.input('Apln_slno',sql.Int,apln_slno);
      request2.input('Effective_Date',sql.Date,Effective_Date);
      request2.input('PayScale_ID',sql.Int,PayScale_ID);
      request2.input('Approved_by', sql.VarChar(10), Requested_By);
      request2.input('Status', sql.VarChar(20), 'PENDING');
       const rest = await request2.execute('UpdateEmpPayscale_R');
       res.status(200).json("Salary (Reworked) Updated and Send for Approval");
    }
    else if(chcek.recordset[0].Approval_Status === 'PENDING' ){
      res.status(400).json("Salary Updated, Waiting For Approval" );
    }
    else if(chcek.recordset[0].Approval_Status === 'APPROVED' ){
      res.status(400).json("Salary Already Approved" );
    }}
    else{
      // New
      console.log('new');
      
      const request = pool.request();
  
      request.input('Apln_slno', apln_slno);
      request.input('PayScale_ID', PayScale_ID);
      request.input('Effective_Date', Effective_Date);
      request.input('Created_By', Requested_By);
      const result = await request.execute('Insert_Emp_Wage');
      // console.log(result.recordset);
        res.status(200).json("Salary Updated and Send for Approval");
    
    }
 

  
   
  } catch (error) {
    console.log(error)
    res.status(400).json("data not found" );
    
  }
  
  
    })
salary.post('/revise_Salry', async(req,res)=>{
  console.log(req.body);
  const{PayScale_ID,plant_Code,Effective_Date,apln_slno, Requested_By } = req.body
  try {
   
    const pool = await db.poolPromise;
    const request1 = pool.request();
    console.log("select * from Mst_Emp_PayScale where Apln_slno= '"+apln_slno+"'");
    
    const chcek = await request1.query("select * from Mst_Emp_PayScale where Apln_slno= '"+apln_slno+"'  ")
console.log(chcek);

console.log(chcek && chcek.recordset.length > 0);



    if(chcek && chcek.recordset.length > 0){
// Exist
      if(chcek.recordset[0].Approval_Status === 'APPROVED' || chcek.recordset[0].Approval_Status === 'REWORK' ){
      const request2 = pool.request();
      request2.input('Apln_slno',sql.Int,apln_slno);
      request2.input('Effective_Date',sql.Date,Effective_Date);
      request2.input('PayScale_ID',sql.Int,PayScale_ID);
      request2.input('Approved_by', sql.VarChar(10), Requested_By);
      request2.input('Status', sql.VarChar(20), 'PENDING');
       const rest = await request2.execute('UpdateEmpPayscale_R1');
       res.status(200).json("Salary  Updated and Send for Approval");
    }
    else if(chcek.recordset[0].Approval_Status === 'PENDING' ){
      res.status(400).json("Salary Updated, Waiting For Approval" );
    }
    else if(chcek.recordset[0].Approval_Status === 'REWORK' ){
      res.status(400).json("Please REWORK Salary" );
    }}
    
 

  
   
  } catch (error) {
    console.log(error)
    res.status(400).json("data not found" );
    
  }
  
  
    })


    salary.get('/updt_pay', async(req,res) => {
      const plant_code =  req.query.plant_Code
      console.log(plant_code)
          try{
              const pool = await db.poolPromise;
              const request = pool.request();
              request.input('plant_code', plant_code)
              const result = await request.execute('salary_list').then(function(recordset){
                  res.status(200).json(recordset.recordset)
              })
      }catch(err){
          console.error('Error executing stored procedure:', err);
          res.status(400).send("Error while Getting data :");
      }
      
      
      })


      salary.get('/view_sal', async(req,res)=>{
        const plant_code = req.query.plant_Code;
        const userEmpcode = req.query.userEmpcode;
        try {
          const pool = await db.poolPromise;
        const request = pool.request();
        request.input('plant_code',plant_code); 
        request.input('userEmpcode',userEmpcode); 
        const result = await request.execute('mst_Wages_list');
        //console.log(result.recordset);
        res.status(200).json(result.recordset);
        } catch (error) {
          res.status(400).json("Error whikle getting Data" );
        }
      })


      salary.put('/appr_sal',async(req,res)=>{
        console.log(req.body)
        const Approved_by = req.query.user
        const {PayScale_ID,Effective_Date,Apln_slno} = req.body
       try {
      
          const pool = await db.poolPromise;
          const request = pool.request();
          request.input('Apln_slno',sql.Int,Apln_slno);
          // request.input('Effective_Date',sql.Date,Effective_Date);
          request.input('PayScale_ID',sql.Int,PayScale_ID);
          // request.input('Apprl_Status','APPROVED');
          result = await request.execute('UpdateEmpPayscale_Chcek');
          console.log(result);
          console.log(result.recordset[0].Approval_Status);
          
      if(result && result.recordset[0] ){
        if(result.recordset[0].Approval_Status === 'APPROVED'){
          console.log(`Salary Already Approved`)
        }else  if(result.recordset[0].Approval_Status === 'PENDING'){
      
          const pool = await db.poolPromise;
          const request1 = pool.request();
          request1.input('Apln_slno',sql.Int,Apln_slno);
          // request1.input('Effective_Date',sql.Date,Effective_Date);
          request1.input('PayScale_ID',sql.Int,PayScale_ID);
          request1.input('Approved_by', sql.VarChar(10), Approved_by);
          request1.input('Status', sql.VarChar(20), 'APPROVED');
          result1 = await request1.execute('UpdateEmpPayscale');
      
          res.status(200).json(`Salary Approved`);
        }
      }
      else{
        res.status(400).json(` Error While Approving Salary Please Refresh and Approve `);
      }
       
      
    } catch (error) {
      console.log(error)
      res.status(400).json(` Error While Approving Salary `);
    }
  })
  
      
      salary.put('/rewrk_sal',async(req,res)=>{
        console.log(req.body)
        // const Approved_by = req.query.user
        const {data,Reject_reason,rejected_by} = req.body
       try {
      
          const pool = await db.poolPromise;
          const request = pool.request();
          request.input('Apln_slno',sql.Int,data.Apln_slno);
          request.input('Effective_Date',sql.Date,data.Effective_Date);
          request.input('PayScale_ID',sql.Int,data.PayScale_ID);

          
          result = await request.execute('UpdateEmpPayscale_Chcek');
          console.log(result);
          console.log(result.recordset[0].Approval_Status);
          
      if(result && result.recordset[0] ){
        if(result.recordset[0].Approval_Status === 'APPROVED'){
          console.log(`Salary Already Approved`)
        }else if(result.recordset[0].Approval_Status === 'PENDING'){
      
          const pool = await db.poolPromise;
          const request1 = pool.request();
          request1.input('Apln_slno',sql.Int,data.Apln_slno);
          request1.input('Effective_Date',sql.Date,data.Effective_Date);
          request1.input('PayScale_ID',sql.Int,data.PayScale_ID);
          request1.input('Approved_by', sql.VarChar(10), rejected_by);
          request1.input('Rework_Reason',sql.VarChar(1000),Reject_reason);
        
          
          result1 = await request1.execute('UpdateReworkEmpPayscale');
      
          res.status(200).json(`Salary Send To Rework`);
        }
      }
      else{
        res.status(400).json(` Error While Approving Salary Please Refresh and Approve `);
      }
      
      
       
      
        } catch (error) {
          console.log(error)
          res.status(400).json(` Error While Approving Salary `);
        }
      })
      


      //appr_Bulk_sal

      salary.post('/appr_Bulk_sal', async (req, res) => {
        const BulkData = req.body;
        const Approved_by = req.query.user
        try {
          let allApproved = true; 
          let approvalMessages = []; 
      
          for (const employee of BulkData) {
            const { apln_slno, PayScale_ID, Effective_Date } = employee;
            const pool = await db.poolPromise;
            const request = pool.request();
            request.input('Apln_slno', sql.Int, apln_slno);
            request.input('Effective_Date', sql.Date, Effective_Date);
            request.input('PayScale_ID', sql.Int, PayScale_ID);
      
            const result = await request.execute('UpdateEmpPayscale_Chcek');
            if (result && result.recordset[0]) {
              if (result.recordset[0].Approval_Status === 'APPROVED') {
                approvalMessages.push(`Salary Already Approved for apln_slno: ${apln_slno}, PayScale_ID: ${PayScale_ID}, Effective_Date: ${Effective_Date}`);
              } else {
                const pool = await db.poolPromise;
                const request1 = pool.request();
                request1.input('Apln_slno', sql.Int, apln_slno);
                // request1.input('Effective_Date', sql.Date, Effective_Date);
                request1.input('PayScale_ID', sql.Int, PayScale_ID);
                request1.input('Approved_by', sql.VarChar(10), Approved_by);
                request1.input('Status', sql.VarChar(20),'APPROVED');
                const result1 = await request1.execute('UpdateEmpPayscale');
                approvalMessages.push(`Salary Approved for apln_slno: ${apln_slno}, PayScale_ID: ${PayScale_ID}, Effective_Date: ${Effective_Date}`);
              }
            } else {
              allApproved = false; // Mark as not approved if any salary is not approved
              approvalMessages.push(`Salary Not Approved for apln_slno: ${apln_slno}, PayScale_ID: ${PayScale_ID}, Effective_Date: ${Effective_Date}`);
            }
          }
      
          if (allApproved) {
            res.status(200).json({ success: true, message: 'All salaries approved', details: approvalMessages });
          } else {
            res.status(200).json({ success: false, message: 'Some salaries not approved', details: approvalMessages });
          }
        } catch (error) {
          console.error(error);
          res.status(500).json({ success: false, message: 'Error while approving salaries', error: error.message });
        }
      });


      salary.get('/emp_Sal_Master',async(req,res)=>{
        const plant_Code = req.query.plant_Code
        console.log(plant_Code);
        
        try {
          const pool = await db.poolPromise;
          const request1 = pool.request();
          request1.input('plant_code',plant_Code)
          const result = await request1.execute('EMP_Salary_Master')
          console.log(result);
          if(result.recordset.length ==0){
            res.status(200).json({status:'Failure', data:result.recordset})
          }else{
            res.status(200).json({status:'Success',data:result.recordset})
          }
          
         
        } catch (error) {
          console.error(error);
          res.status(500).json({ success: false, message: 'Error while dowloading Employee Salary Master', error: error.message });
      
        }
      })

      salary.get('/getPayroll',async(req,res)=>{
        const Plant_code = req.query.Plant_code;
        try {
          const pool = await db.poolPromise;
          const request = pool.request();
          request.input('plant',Plant_code); 
          const result = await request.execute('PayrollDateforTrainee');
          res.status(200).json(result.recordset);
        } catch (error) {
          res.status(400).json("Error while getting Data" );
          console.log(error)
        }
      })
      salary.get('/getPayrollForOnrTime',async(req,res)=>{
        const Plant_code = req.query.plant_Code;
        try {
          const pool = await db.poolPromise;
          const request = pool.request();
          request.input('plant',Plant_code); 
          const result = await request.execute('GetPayrollDates');
          res.status(200).json(result.recordset);
        } catch (error) {
          res.status(400).json("Error while getting Data" );
          console.log(error)
        }
      })


      salary.get('/getonetimeSal',async(req,res)=>{
        const Plant_code = req.query.plant_Code;
        try {
          const pool = await db.poolPromise;
          const request = pool.request();
          request.input('plant',Plant_code); 
          const result = await request.execute('GetOneTimeSalary');
          res.status(200).json(result.recordset);
        } catch (error) {
          res.status(400).json("Error while getting Data" );
          console.log(error)
        }
      })




      salary.post('/VerifyOTDE',upload_1.single('file'),async(req,res) =>{
        try {
          if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        } else{
          const Plant_code = req.query.plant_Code;
          const workbook = xlsx.read(req.file.buffer, { type: 'buffer' });
          const sheet1 = workbook.Sheets[workbook.SheetNames[0]];
          const sheet2 = workbook.Sheets[workbook.SheetNames[1]];

          const Earnigns_Data = xlsx.utils.sheet_to_json(sheet1, { defval:''  })
          const Deduction_Data = xlsx.utils.sheet_to_json(sheet2, { defval:''  })


console.log('Earnigns_Data',Earnigns_Data);
console.log('Deduction_Data',Deduction_Data);
const pool = await db.poolPromise;
if(Earnigns_Data.length ==0  && Deduction_Data.length == 0){
  res.status(400).json('Data Records Does Not Exist')
}
else if(Earnigns_Data.length >0  && Deduction_Data.length == 0){
  console.log('ONly earnings');
  
  const request = pool.request();
  const tableEarnings = new sql.Table("#Trn_Onetime_Earnings");
  tableEarnings.create = true;
  tableEarnings.columns.add("Date", sql.VarChar(20), { nullable: false });
  tableEarnings.columns.add("gen_id", sql.VarChar(20), { nullable: false });
  tableEarnings.columns.add("Earning_Description", sql.VarChar(255), { nullable: false });
  tableEarnings.columns.add("Earning_Amount", sql.Decimal(12, 2), { nullable: false });
  Earnigns_Data.forEach(item => {
    const Payroll_Date = convertExcelDatetimeToDatetime(item.Date);
    tableEarnings.rows.add(
        Payroll_Date,
        item.Gen_ID,
        item['Earnig Description'],
        item['Earning Amount']
    );
  });

await request.bulk(tableEarnings);
request.input('plant', sql.Int,Plant_code)
const result1 = await request.execute('VerifyOneTimeSal_Earning ')
console.log(result1);
res.status(200)
.json({
  Ear_Valid : result1.recordsets[0],
  Ear_Invalid : result1.recordsets[1]
})


}
else if(Earnigns_Data.length ==0  && Deduction_Data.length > 0){
  console.log('ONly Deductions');
  const request = pool.request();
  const tableDeductions = new sql.Table("#Trn_Onetime_Deductions");
  tableDeductions.create = true;
  tableDeductions.columns.add("Date", sql.Date, { nullable: false });
  tableDeductions.columns.add("gen_id", sql.VarChar(20), { nullable: false });
  tableDeductions.columns.add("Deduction_Description", sql.VarChar(255), { nullable: false });
  tableDeductions.columns.add("Deduction_Amount", sql.Decimal(12, 2), { nullable: false });

  Deduction_Data.forEach(item => {
    const Payroll_Date = convertExcelDatetimeToDatetime(item.Date);
    tableDeductions.rows.add(
        Payroll_Date,
        `${item.Gen_ID}`,
        item['Dedution Description'],
        item['Dedcution Amount']
    );
  });

  console.log(tableDeductions);
  
  await request.bulk(tableDeductions);
  request.input('plant', sql.Int,Plant_code)
  const result1 = await request.execute('VerifyOneTimeSal_Deduction')
  console.log(result1.recordsets[0]);
  console.log(result1.recordsets[1]);
  console.log(result1.recordsets[2]);
res.status(200)
.json({
  Ded_Valid : result1.recordsets[0],
  Ded_Invalid : result1.recordsets[1]
})

}
else{
  console.log('Both  earnings and deduction');

  const request = pool.request();
  const tableEarnings = new sql.Table("#Trn_Onetime_Earnings");
  tableEarnings.create = true;
  tableEarnings.columns.add("Date", sql.VarChar(20), { nullable: false });
  tableEarnings.columns.add("gen_id", sql.VarChar(20), { nullable: false });
  tableEarnings.columns.add("Earning_Description", sql.VarChar(255), { nullable: false });
  tableEarnings.columns.add("Earning_Amount", sql.Decimal(12, 2), { nullable: false });
  Earnigns_Data.forEach(item => {
    const Payroll_Date = convertExcelDatetimeToDatetime(item.Date);
    tableEarnings.rows.add(
        Payroll_Date,
        item.Gen_ID,
        item['Earnig Description'],
        item['Earning Amount']
    );
  });

const tableDeductions = new sql.Table("#Trn_Onetime_Deductions");
tableDeductions.create = true;
tableDeductions.columns.add("Date", sql.Date, { nullable: false });
tableDeductions.columns.add("gen_id", sql.VarChar(20), { nullable: false });
tableDeductions.columns.add("Deduction_Description", sql.VarChar(255), { nullable: false });
tableDeductions.columns.add("Deduction_Amount", sql.Decimal(12, 2), { nullable: false });
  Deduction_Data.forEach(item => {
    const Payroll_Date = convertExcelDatetimeToDatetime(item.Date);
    tableDeductions.rows.add(
        Payroll_Date,
        item.Gen_ID,
        item['Dedution Description'],
        item['Dedcution Amount']
    );
  });



console.log(tableEarnings);
console.log(tableDeductions);

await request.bulk(tableEarnings);
await request.bulk(tableDeductions);
request.input('plant', sql.Int,Plant_code)
const result1 = await request.execute('VerifyOneTimeSal')
// const result1 = await request.execute('VerifyOneTime_Ear_Ded1')

console.log(result1);
res.status(200)
.json({
  Ear_Valid : result1.recordsets[0],
  Ded_Valid : result1.recordsets[1],
  Ear_Invalid : result1.recordsets[2],
  Ded_Invalid : result1.recordsets[3],
})

}
        }

       } catch (error) {
          console.error(error);
          res.status(500).json({ success: false, message: 'Error while verifying', error: error.message });
  
        }
      }) 
      



salary.post('/otn_Salry',async(req,res)=>{
try {
  const {Earning,Deduction,plant_code,user}= req.body
const pool = await db.poolPromise;
const request1 = pool.request();
const table = new sql.Table("#Submitted_Earnings_and_Deductions");
table.create = true;
table.columns.add("cemp_id", sql.Int, { nullable: true });
  table.columns.add("Date",  sql.Date, { nullable: true });
  table.columns.add("gen_id", sql.VarChar(20), { nullable: true });
  table.columns.add("Type", sql.VarChar(50), { nullable: true });
  table.columns.add("Description", sql.VarChar(255), { nullable: true });
  table.columns.add("Amount", sql.Decimal(12, 2), { nullable: true });


console.log(Earning.length);
console.log(Deduction.length);


  if(Earning.length>0){
    Earning.forEach(item => {
      console.log(item);
      table.rows.add(
        item.apln_slno,
        item.Date,
        item.gen_id,
        'Earning',
        item.Earning_Description,
        item.Earning_Amount
      );
    });
  
  }

  if(Deduction.length > 0){
    Deduction.forEach(item => {
      table.rows.add(
        item.apln_slno,
        item.Date,
        item.gen_id,
        'Deduction',
        item.Deduction_Description,
        item.Deduction_Amount
      );
    });
  }
 console.log(table);     
  const t2 =await request1.bulk(table);
  request1.input('plant',plant_code)
request1.input('Uploaded_By',user)
const insertEar = await request1.execute('OneTime_Salary')

  

res.status(200).json("Submitted for HR Approval")

} catch (error) {
  console.error(error);
  res.status(500).json({ success: false, message: 'Error while Submitting Onw Time Salary', error: error.message });

}
 })

salary.post('/approve_otn_Salry',async(req,res) =>{
  try {
    console.log(req.body);

    const {Approved_Data ,details , plant_code ,user} = req.body
    const pool = await db.poolPromise;
      console.log(Approved_Data);
      
    const request1 = pool.request()
     request1.input('plant',plant_code) 
    const rest = await request1.execute('GetPayrollDates')
      // `Select format(DATEADD(MONTH, 1, MAX(bill_processed_st)),'yyyy-MM-dd') as bill_processed_st,format(DATEADD(MONTH, 1, MAX(bill_prossed_enddt)) ,'yyyy-MM-dd')  as bill_prossed_enddt from trn_bill_processed_dt where plant_Code=${plant_code} and  category='T'`)

    console.log(rest);
const bill_processed_st =rest.recordset[0].bill_processed_st
const bill_prossed_enddt =rest.recordset[0].bill_prossed_enddt
const from = Approved_Data.min_from
const to = Approved_Data.max_from

const billProcessedDate = new Date(bill_processed_st);
const billProcessedEndDate = new Date(bill_prossed_enddt);
const fromDate = new Date(from);
const toDate = new Date(to);


if (fromDate < billProcessedDate || toDate > billProcessedEndDate) {
  return res.status(400).json({
    error: 'Date range is not within the processed bill period',
    message: `Payroll Already locked, Not able to Approve `
  });
}
else{
    const request = pool.request();
request.input('Request_ID',Approved_Data.Request_Id)
request.input('Plant',plant_code)
request.input('Approved_By',user)
const result = await request.execute('ApproveOneTimeSalary')
console.log(result);
res.status(200).json({success:true,  message:`${result.rowsAffected[0]} Records Approved`})
}
  } catch (error) {
    console.error('Error while Approving', error);
    res.status(500).json({ success: false, message: 'Error while Approving', error: error.message });

  }
 })
salary.post('/reject_otn_Salry',async(req,res) =>{
  try {
    console.log(req.body);
    const {Rejected_Data ,details , plant_code ,user} = req.body
    const pool = await db.poolPromise;
   
    const request1 = pool.request()
    const rest = await request1.query(`Select format(DATEADD(MONTH, 1, MAX(bill_processed_st)),'yyyy-MM-dd') as bill_processed_st,format(DATEADD(MONTH, 1, MAX(bill_prossed_enddt)) ,'yyyy-MM-dd')  as bill_prossed_enddt from trn_bill_processed_dt where plant_Code=${plant_code} and  category='T'`)

    console.log(rest);
const bill_processed_st =rest.recordset[0].bill_processed_st
const bill_prossed_enddt =rest.recordset[0].bill_prossed_enddt
const from = Approved_Data.min_from
const to = Approved_Data.max_from

const billProcessedDate = new Date(bill_processed_st);
const billProcessedEndDate = new Date(bill_prossed_enddt);
const fromDate = new Date(from);
const toDate = new Date(to);


if (fromDate < billProcessedDate || toDate > billProcessedEndDate) {
  return res.status(400).json({
    error: 'Date range is not within the processed bill period',
    message: `Payroll Already locked, Not able to Approve`
  });
}
else{
    const request = pool.request();
request.input('Request_ID',Rejected_Data.Request_Id)
request.input('Plant',plant_code)
request.input('Approved_By',user)
 const result = await request.execute('RejectOneTimeSalary')
console.log(result);
res.status(200).json({success:true,  message:`${result.rowsAffected[0]} Records Rejected`})
}
  } catch (error) {
    console.error('Error while Rejecting', error);
    res.status(500).json({ success: false, message: 'Error while Rejecting', error: error.message });

  }
 })




 salary.get('/Salreports',async(req,res)=>{
  try{
    let {plant,from,to,type,cont}=req.query;
    console.log(plant,from,to,type,cont);
    let chcek=''
    let query=``
    const pool = await db.poolPromise 
    switch(type){   
      case 'OTMSAL':
        query=`exec GetOnetimeSalaryReport '${plant}','${from}','${to}'`;
        break;
      case 'PRSAL':
        const request1 = pool.request()
        const exist_data1 = await request1.query(" SELECT COUNT(*) AS ct FROM trn_Processed_Salary WHERE Plant = '"+plant+"'   AND Fromdate ='"+from+"' AND Todate = '"+to+"' ");
        if(exist_data1.recordset[0].ct >0){
          chcek=false
        query=`exec Previous_Processed_salary_report '${plant}','${from}','${to}',${cont}`;
        }
        else{
          chcek=false
          if(plant == 1250){
          query=`exec Final_Non_SAP_Salary_Contractor_Wise_P5 '${plant}','${from}','${to}',${cont}`;
          }
          else if(plant==8005){
             query=`exec Final_Non_SAP_Salary_Contractor_Wise_LMCI '${plant}','${from}','${to}',${cont}`;
          }
          else if(plant==8010){
             query=`exec Final_Non_SAP_Salary_Contractor_Wise_LMCI '${plant}','${from}','${to}',${cont}`;
          }
          else if(plant == 1000){
            query=`exec Final_Non_SAP_Salary_Contractor_Wise_HO '${plant}','${from}','${to}',${cont}`;

          }
          else{
            query=`exec Final_Non_SAP_Salary_Contractor_Wise '${plant}','${from}','${to}',${cont}`;
          }

        }
        break;
      case 'CTSAL':
      
      const request = pool.request()
        const exist_data = await request.query(" SELECT COUNT(*) AS ct FROM trn_Processed_Salary WHERE Plant = '"+plant+"'   AND Fromdate ='"+from+"' AND Todate = '"+to+"' ");
        if(exist_data.recordset[0].ct >0){
          chcek=true
        }else{
          chcek=false
          if(plant == 1250){
            query=`exec Final_Non_SAP_Salary_Contractor_Wise_P5 '${plant}','${from}','${to}',${cont}`;

          }
          else if(plant==8005){
             query=`exec Final_Non_SAP_Salary_Contractor_Wise_LMCI_new '${plant}','${from}','${to}',${cont}`;
          }
          else if(plant==8010){
             query=`exec Final_Non_SAP_Salary_Contractor_Wise_LMCI_new '${plant}','${from}','${to}',${cont}`;
          }
          else if(plant == 1000){
            query=`exec Final_Non_SAP_Salary_Contractor_Wise_HO '${plant}','${from}','${to}',${cont}`;

          }
          else{
          query=`exec Final_Non_SAP_Salary_Contractor_Wise '${plant}','${from}','${to}',${cont}`;
          }
        }
        break;

    }
    console.log(query)
    const result = await pool.request().query(query)

    if(result.rowsAffected==0){
      res.send({status:'failed',message:'No data Found'})
    }
    else{
        if(type == 'PRSAL' ){
          res.send({status:'success',data:result.recordsets}) 
        }
        else  if( type == 'CTSAL' ){
if(chcek ==true){
  res.send({status:'failed',message:'Payroll Locked, Please download data in Previous payroll Option'})

}else if(chcek==false){
  res.send({status:'success',data:result.recordsets}) 

}

        }
        
        else{
          res.send({status:'success',data:result.recordset}) 
        }



       
    }
  }catch(error){
    console.log(error)
    res.send({status:'failed',message:'Someting went wrong while fetching  Report'})
  }
})




      

function convertExcelDatetimeToDatetime(excelDatetime) {
  // Extract days and fraction part
  const days = Math.floor(excelDatetime);
  const fraction = excelDatetime - days;

  // Convert days to milliseconds
  const millisecondsPerDay = 24 * 60 * 60 * 1000;
  const daysMilliseconds = days * millisecondsPerDay;

  // Creating Date object for the Excel epoch
  const excelEpoch = new Date(Date.UTC(1899, 11, 30));

  // Adding days to the Excel epoch
  const excelDate = new Date(excelEpoch.getTime() + daysMilliseconds);

  // Extracting time components
  const hours = Math.floor(fraction * 24);
  const minutes = Math.floor((fraction * 24 * 60) % 60);
  const seconds = Math.floor((fraction * 24 * 60 * 60) % 60);

  // Formatting the date
  const yyyy = excelDate.getUTCFullYear();
  const mm = String(excelDate.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(excelDate.getUTCDate()).padStart(2, '0');
  const hh = String(hours).padStart(2, '0');
  const min = String(minutes).padStart(2, '0');
  const ss = String(seconds).padStart(2, '0');

  // Constructing the formatted datetime string
  const formattedDatetime = `${yyyy}-${mm}-${dd}`;
  // const dateObject =  new Date(formattedDatetime);
  // // console.log(formattedDatetime);
  return formattedDatetime;
  
}


// ------------------------------- corrected till here 




salary.get('/getDept',async(req,res)=>{
  const Plant_code = req.query.Plant_code;
  try {
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('Plant_code',Plant_code); 
    const result = await request.execute('get_dept');
    res.status(200).json(result.recordset);
  } catch (error) {
    res.status(400).json("Error while getting Data" );
    console.log(error)
  }
})







function convertNullToDecimal(value) {
  console.log(value === 'null' ? null : parseFloat(value))
  return value === 'null' ? null : parseFloat(value);
}
async function chk_efctDt_greater_LockDt(Effective_from,Plant_code){
  try {
    console.log(Effective_from,Plant_code)
    const pool = await db.poolPromise;
  const request1= pool.request();
  request1.input('New_Effective_Date',Effective_from);
  request1.input('plant_code',Plant_code);
  const efct_date_exist = await request1.execute(`efct_date_greater_lock_date`)
  console.log(efct_date_exist.recordset[0].result)
  return efct_date_exist.recordset[0].result
  } catch (error) {
    console.log(error)
    // return 'NO'
  }
}



salary.get('/wage_list',async(req,res)=>{
  try {
    const Plant_code = req.query.Plant_code;
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('plant_code',Plant_code);
    const  result=  await request.execute(`get_wage_list_for_Revise_Salary`)
      res.status(200).json(result.recordset)
  
 
  } catch (error) {
    res.status(400).json("Error while getting Data" );
    console.log(error)
  }
})


salary.get('/non_Sap', async(req,res)=>{
  try {
   
    const pool = await db.poolPromise;
    const request = pool.request();
    const  result=  await request.execute(`non_sap_category_list`)
    res.status(200).json(result.recordset)
  } catch (error) {
    res.status(400).json("Error while getting Data" );
    console.log(error)
  }
})


salary.get('/Payscale_mst_new', async(req,res)=>{
  try {
    const Plant_code = req.query.plant_Code;
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('plant',Plant_code);
    const  result=  await request.execute(`getPayscleMaster`)
    res.status(200).json(result.recordset)
  } catch (error) {
    res.status(400).json("Error while getting Data" );
    console.log(error)
  }
})
salary.get('/Payscale_mst_new_combine', async(req,res)=>{
  try {
    const Plant_code = req.query.plant_Code;
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('userEmpcode',userEmpcode);
    request.input('plant',Plant_code);
    const  result=  await request.execute(`getPayscleMaster_combine`)
    res.status(200).json(result.recordset)
  } catch (error) {
    res.status(400).json("Error while getting Data" );
    console.log(error)
  }
})
salary.post('/new_PayscaleHead', async(req,res)=>{
  try {

    console.log(req.body);
    
    const data = req.body;
    const created_by = req.query.created_by;
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('Plant_Code',data.Plant_Code);
    request.input('Cont_ID',data.Cont_ID);
    request.input('PayScale_Name',data.PayScale_Name);
    request.input('Created_By',created_by);
    const  result=  await request.execute(`Insert_Mst_PayScale_Header`)
    res.status(200).json(result.recordset)
  } catch (error) {
    res.status(400).json("Error while getting Data" );
    console.log(error)
  }
})
salary.post('/update_PayscaleHead', async(req,res)=>{
  try {

    console.log(req.body);
    const data = req.body;
    const created_by = req.query.created_by;
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('PayScale_ID',data.PayScale_ID);
    request.input('PayScale_Name',data.PayScale_Name);
    request.input('Modified_By',created_by);
    const  result=  await request.execute(`Update_Mst_PayScale_New`)
    res.status(200).json(result.recordset)
  } catch (error) {
    res.status(400).json("Error while getting Data" );
    console.log(error)
  }
})
salary.post('/delete_PayscaleHead', async(req,res)=>{
  try {

    console.log(req.body);
    const data = req.body;
    const created_by = req.query.created_by;
    const pool = await db.poolPromise;
    const request = pool.request();
    request.input('PayScale_ID',data.PayScale_ID);
    request.input('Modified_By',created_by);
    const  result=  await request.execute(`Delete_Mst_PayScale_New`)
    res.status(200).json(result.recordset)
  } catch (error) {
    res.status(400).json("Error while getting Data" );
    console.log(error)
  }
})


salary.post('/bulk_punch_process', async(req, res) => {

  console.log('bulk_punch_process',req.body);
  try {
    const pool = await db.poolPromise;
    const From = req.body.from;
    const To = req.body.to;
    const Plant = req.body.plant;

    const request = await pool.request()
      .input('fromdate', From)
      .input('todate', To)
      .input('plant', Plant)
      .execute('Attendance_New_Process_Plant_New');

      res.status(200).json({ message: 'Attedance Reprocessed Successfully'})
  } catch (error) {
    res.status(400).json({ message: 'Attendance Reprocess Error, Contact IT Team'});
    console.log(error)
  }
});






module.exports = salary;